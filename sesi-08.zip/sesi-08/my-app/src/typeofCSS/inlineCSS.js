import React from 'react';

function CobaInlineCSS() {
    return (
        <div style={{ backgroundColor: "#8ecae6", padding: "30px", fontFamily: "Arial" }}>
            <h1>Hello World Inline CSS 2022</h1>
        </div>
    )
}

export default CobaInlineCSS;
