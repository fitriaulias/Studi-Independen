const divStyle = {
    backgroundColor: "#ffb703",
    padding: "30px",
    fontFamily: "Arial"
}

export default divStyle;