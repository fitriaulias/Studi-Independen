import React from 'react';
import './external.css';

function CobaExternalCSS() {
    return (
        <div className='container'>
            <h1>Hello External CSS 2022</h1>
        </div>
    );
}

export default CobaExternalCSS;