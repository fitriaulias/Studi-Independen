import React from 'react';
import divStyle from './ObjectVariableCSSExternal';

function CobaExternalObjectVariableCSS() {
    return (
        <div style={ divStyle }>
            <h1>Hello External Object Variable 2022</h1>
        </div>
    )
}

export default CobaExternalObjectVariableCSS;