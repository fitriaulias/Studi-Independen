import React from 'react';

function About() {
    return (
        <>
        <div style={{ backgroundColor: "#f5cac3", padding: "50px", fontFamily: "Arial", textAlign: "center" }}>
            <p>Nama: Fitri Aulia S.</p>
            <p>Kode Peserta: RCTN-005-024</p>
        </div>
        </>
    )
}

export default About;