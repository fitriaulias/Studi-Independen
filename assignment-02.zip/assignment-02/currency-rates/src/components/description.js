import React from 'react';

function Description() {
    return (
    <>
        <p>Rates are based from 1 USD
        <br/>
        This Application uses API from https://currencyfreaks.com
        </p>
    </>
    )
}

export default Description;